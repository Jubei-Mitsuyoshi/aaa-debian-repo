/* automatically generated from ./thunar-launcher-ui.xml */
#ifdef __SUNPRO_C
#pragma align 4 (thunar_launcher_ui)
#endif
#ifdef __GNUC__
static const char thunar_launcher_ui[] __attribute__ ((__aligned__ (4))) =
#else
static const char thunar_launcher_ui[] =
#endif
{
  "<ui><menubar name=\"main-menu\"><menu action=\"file-menu\"><placeholder"
  " name=\"placeholder-launcher\"><menuitem action=\"open\" /><menuitem ac"
  "tion=\"open-in-new-tab\" /><menuitem action=\"open-in-new-window\" /><p"
  "laceholder name=\"placeholder-applications\" /><menuitem action=\"open-"
  "with-other\" /><menu action=\"open-with-menu\"><placeholder name=\"plac"
  "eholder-applications\" /><separator /><menuitem action=\"open-with-othe"
  "r-in-menu\" /></menu><placeholder name=\"placeholder-actions\" /></plac"
  "eholder><menu action=\"sendto-menu\"><placeholder name=\"placeholder-se"
  "ndto-actions\"><menuitem action=\"sendto-desktop\" /><separator /></pla"
  "ceholder></menu></menu></menubar><popup action=\"file-context-menu\"><p"
  "laceholder name=\"placeholder-launcher\"><menuitem action=\"open\" /><m"
  "enuitem action=\"open-in-new-tab\" /><menuitem action=\"open-in-new-win"
  "dow\" /><placeholder name=\"placeholder-applications\" /><menuitem acti"
  "on=\"open-with-other\" /><menu action=\"open-with-menu\"><placeholder n"
  "ame=\"placeholder-applications\" /><separator /><menuitem action=\"open"
  "-with-other-in-menu\" /></menu><placeholder name=\"placeholder-actions\""
  " /></placeholder><menu action=\"sendto-menu\"><placeholder name=\"place"
  "holder-sendto-actions\"><menuitem action=\"sendto-desktop\" /><separato"
  "r /></placeholder></menu></popup></ui>"
};

static const unsigned thunar_launcher_ui_length = 1259u;

