msginit -l or_IN -o oriya.po -i timeshift.pot

echo "Finished"
read dummy
