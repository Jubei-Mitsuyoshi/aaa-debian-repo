/* automatically generated from ./thunar-abstract-icon-view-ui.xml */
#ifdef __SUNPRO_C
#pragma align 4 (thunar_abstract_icon_view_ui)
#endif
#ifdef __GNUC__
static const char thunar_abstract_icon_view_ui[] __attribute__ ((__aligned__ (4))) =
#else
static const char thunar_abstract_icon_view_ui[] =
#endif
{
  "<ui><menubar name=\"main-menu\"><menu action=\"view-menu\"><placeholder"
  " name=\"placeholder-view-items-actions\"><menu action=\"arrange-items-m"
  "enu\"><menuitem action=\"sort-by-name\" /><menuitem action=\"sort-by-si"
  "ze\" /><menuitem action=\"sort-by-type\" /><menuitem action=\"sort-by-m"
  "time\" /><separator /><menuitem action=\"sort-ascending\" /><menuitem a"
  "ction=\"sort-descending\" /></menu></placeholder></menu></menubar><popu"
  "p action=\"folder-context-menu\"><placeholder name=\"placeholder-view-i"
  "tems-actions\"><menu action=\"arrange-items-menu\"><menuitem action=\"s"
  "ort-by-name\" /><menuitem action=\"sort-by-size\" /><menuitem action=\""
  "sort-by-type\" /><menuitem action=\"sort-by-mtime\" /><separator /><men"
  "uitem action=\"sort-ascending\" /><menuitem action=\"sort-descending\" "
  "/></menu></placeholder></popup></ui>"
};

static const unsigned thunar_abstract_icon_view_ui_length = 779u;

