#define NEW csd_mouse_manager_new
#define START csd_mouse_manager_start
#define STOP csd_mouse_manager_stop
#define MANAGER CsdMouseManager
#include "csd-mouse-manager.h"

#include "test-plugin.h"
