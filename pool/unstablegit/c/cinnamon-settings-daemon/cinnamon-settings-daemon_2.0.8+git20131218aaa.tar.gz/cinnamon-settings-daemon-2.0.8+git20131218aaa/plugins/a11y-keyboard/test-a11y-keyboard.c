#define NEW csd_a11y_keyboard_manager_new
#define START csd_a11y_keyboard_manager_start
#define STOP csd_a11y_keyboard_manager_stop
#define MANAGER CsdA11yKeyboardManager
#include "csd-a11y-keyboard-manager.h"

#include "test-plugin.h"
