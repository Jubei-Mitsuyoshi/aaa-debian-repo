self.description = "Test command line option (--help)"

self.args = "--help"

self.addrule("PACMAN_RETCODE=2")
