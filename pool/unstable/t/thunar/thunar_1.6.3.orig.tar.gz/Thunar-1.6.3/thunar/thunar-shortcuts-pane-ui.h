/* automatically generated from ./thunar-shortcuts-pane-ui.xml */
#ifdef __SUNPRO_C
#pragma align 4 (thunar_shortcuts_pane_ui)
#endif
#ifdef __GNUC__
static const char thunar_shortcuts_pane_ui[] __attribute__ ((__aligned__ (4))) =
#else
static const char thunar_shortcuts_pane_ui[] =
#endif
{
  "<ui><menubar name=\"main-menu\"><menu action=\"file-menu\"><menu action"
  "=\"sendto-menu\"><placeholder name=\"placeholder-sendto-sidepane\"><men"
  "uitem action=\"sendto-shortcuts\" /></placeholder></menu></menu></menub"
  "ar><popup action=\"file-context-menu\"><menu action=\"sendto-menu\"><pl"
  "aceholder name=\"placeholder-sendto-sidepane\"><menuitem action=\"sendt"
  "o-shortcuts\" /></placeholder></menu></popup></ui>"
};

static const unsigned thunar_shortcuts_pane_ui_length = 387u;

