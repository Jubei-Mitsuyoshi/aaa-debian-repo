/* automatically generated from ./thunar-renamer-dialog-ui.xml */
#ifdef __SUNPRO_C
#pragma align 4 (thunar_renamer_dialog_ui)
#endif
#ifdef __GNUC__
static const char thunar_renamer_dialog_ui[] __attribute__ ((__aligned__ (4))) =
#else
static const char thunar_renamer_dialog_ui[] =
#endif
{
  "<ui><toolbar name=\"toolbar\"><toolitem action=\"add-files\" /><toolite"
  "m action=\"remove-files\" /><separator /><toolitem action=\"clear\" /><"
  "separator expand=\"true\" /><toolitem action=\"about\" /></toolbar><men"
  "ubar name=\"main-menu\"><menu action=\"file-menu\"><placeholder name=\""
  "placeholder-launcher\" /><separator /><menu action=\"sendto-menu\"><pla"
  "ceholder name=\"placeholder-sendto-actions\" /></menu></menu></menubar>"
  "<popup action=\"file-context-menu\"><placeholder name=\"placeholder-lau"
  "ncher\" /><separator /><menu action=\"sendto-menu\"><placeholder name=\""
  "placeholder-sendto-actions\" /></menu><separator /><placeholder name=\""
  "placeholder-renamer-actions\" /><separator /><menuitem action=\"add-fil"
  "es\" /><menuitem action=\"remove-files\" /><separator /><menuitem actio"
  "n=\"properties\" /></popup></ui>"
};

static const unsigned thunar_renamer_dialog_ui_length = 776u;

