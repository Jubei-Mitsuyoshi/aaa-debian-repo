/* automatically generated from ./thunar-standard-view-ui.xml */
#ifdef __SUNPRO_C
#pragma align 4 (thunar_standard_view_ui)
#endif
#ifdef __GNUC__
static const char thunar_standard_view_ui[] __attribute__ ((__aligned__ (4))) =
#else
static const char thunar_standard_view_ui[] =
#endif
{
  "<ui><menubar name=\"main-menu\"><menu action=\"file-menu\"><placeholder"
  " name=\"placeholder-create-actions\"><menuitem action=\"create-folder\""
  " /><menuitem action=\"create-document\" /></placeholder><placeholder na"
  "me=\"placeholder-file-properties\"><menuitem action=\"properties\" /></"
  "placeholder></menu><menu action=\"edit-menu\"><placeholder name=\"place"
  "holder-edit-clipboard-actions\"><menuitem action=\"cut\" /><menuitem ac"
  "tion=\"copy\" /><menuitem action=\"paste\" /><separator /><menuitem act"
  "ion=\"move-to-trash\" /><menuitem action=\"delete\" /></placeholder><pl"
  "aceholder name=\"placeholder-edit-select-actions\"><menuitem action=\"s"
  "elect-all-files\" /><menuitem action=\"select-by-pattern\" /><menuitem "
  "action=\"invert-selection\" /></placeholder><placeholder name=\"placeho"
  "lder-edit-alter-actions\"><menuitem action=\"duplicate\" /><menuitem ac"
  "tion=\"make-link\" /><menuitem action=\"rename\" /><menuitem action=\"r"
  "estore\" /></placeholder></menu><menu action=\"go-menu\"><placeholder n"
  "ame=\"placeholder-go-history-actions\"><menuitem action=\"back\" /><men"
  "uitem action=\"forward\" /></placeholder></menu></menubar><popup action"
  "=\"file-context-menu\"><placeholder name=\"placeholder-clipboard-action"
  "s\"><menuitem action=\"cut\" /><menuitem action=\"copy\" /><menuitem ac"
  "tion=\"paste-into-folder\" /><separator /><menuitem action=\"move-to-tr"
  "ash\" /><menuitem action=\"delete\" /></placeholder><placeholder name=\""
  "placeholder-edit-actions\"><menuitem action=\"rename\" /><menuitem acti"
  "on=\"restore\" /></placeholder><placeholder name=\"placeholder-file-act"
  "ions\"><menuitem action=\"properties\" /></placeholder></popup><popup a"
  "ction=\"folder-context-menu\"><menuitem action=\"create-folder\" /><men"
  "uitem action=\"create-document\" /><menuitem action=\"empty-trash\" /><"
  "separator /><menuitem action=\"paste\" /><separator /><placeholder name"
  "=\"placeholder-custom-actions\" /><separator /><placeholder name=\"plac"
  "eholder-view-items-actions\" /><separator /><menuitem action=\"zoom-in\""
  " /><menuitem action=\"zoom-out\" /><menuitem action=\"zoom-reset\" /><s"
  "eparator /><menuitem action=\"properties\" /></popup><toolbar name=\"lo"
  "cation-toolbar\"><placeholder name=\"placeholder-history-actions\"><too"
  "litem action=\"back\" /><toolitem action=\"forward\" /></placeholder></"
  "toolbar></ui>"
};

static const unsigned thunar_standard_view_ui_length = 2179u;

