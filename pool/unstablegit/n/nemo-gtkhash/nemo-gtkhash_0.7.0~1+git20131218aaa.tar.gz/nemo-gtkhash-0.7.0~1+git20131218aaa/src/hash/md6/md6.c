#include "md6_compress.c"
#include "md6_mode.c"
