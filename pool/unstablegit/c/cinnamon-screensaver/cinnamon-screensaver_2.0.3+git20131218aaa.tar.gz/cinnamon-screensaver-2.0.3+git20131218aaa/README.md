
 - White big Time/date on x11 background (ala Windows 8)? Background can be shaded with opacity 0.5 using cairo.
 - Round GTK plug corners using cairo and paint it dark?
