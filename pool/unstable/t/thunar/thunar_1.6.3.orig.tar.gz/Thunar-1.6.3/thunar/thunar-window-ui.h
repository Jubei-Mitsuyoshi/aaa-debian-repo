/* automatically generated from ./thunar-window-ui.xml */
#ifdef __SUNPRO_C
#pragma align 4 (thunar_window_ui)
#endif
#ifdef __GNUC__
static const char thunar_window_ui[] __attribute__ ((__aligned__ (4))) =
#else
static const char thunar_window_ui[] =
#endif
{
  "<ui><menubar name=\"main-menu\"><menu action=\"file-menu\"><menuitem ac"
  "tion=\"new-tab\" /><menuitem action=\"new-window\" /><separator /><plac"
  "eholder name=\"placeholder-create-actions\" /><separator /><placeholder"
  " name=\"placeholder-launcher\" /><separator /><menu action=\"sendto-men"
  "u\"><placeholder name=\"placeholder-sendto-sidepane\" /><placeholder na"
  "me=\"placeholder-sendto-actions\" /></menu><separator /><placeholder na"
  "me=\"placeholder-custom-actions\" /><separator /><placeholder name=\"pl"
  "aceholder-file-properties\" /><separator /><menuitem action=\"empty-tra"
  "sh\" /><separator /><menuitem action=\"detach-tab\" /><separator /><men"
  "uitem action=\"close-all-windows\" /><menuitem action=\"close-tab\" /><"
  "menuitem action=\"close-window\" /></menu><menu action=\"edit-menu\"><p"
  "laceholder name=\"placeholder-edit-clipboard-actions\" /><separator /><"
  "placeholder name=\"placeholder-edit-select-actions\" /><separator /><pl"
  "aceholder name=\"placeholder-edit-alter-actions\" /><separator /><place"
  "holder name=\"placeholder-custom-preferences\" /><menuitem action=\"pre"
  "ferences\" /></menu><menu action=\"view-menu\"><menuitem action=\"reloa"
  "d\" /><separator /><menu action=\"view-location-selector-menu\"><menuit"
  "em action=\"view-location-selector-pathbar\" /><menuitem action=\"view-"
  "location-selector-toolbar\" /></menu><menu action=\"view-side-pane-menu"
  "\"><menuitem action=\"view-side-pane-shortcuts\" /><menuitem action=\"v"
  "iew-side-pane-tree\" /></menu><menuitem action=\"view-statusbar\" /><me"
  "nuitem action=\"view-menubar\" /><separator /><menuitem action=\"show-h"
  "idden\" /><separator /><placeholder name=\"placeholder-view-items-actio"
  "ns\" /><separator /><menuitem action=\"zoom-in\" /><menuitem action=\"z"
  "oom-out\" /><menuitem action=\"zoom-reset\" /><separator /><menuitem ac"
  "tion=\"view-as-icons\" /><menuitem action=\"view-as-detailed-list\" /><"
  "menuitem action=\"view-as-compact-list\" /></menu><menu action=\"go-men"
  "u\"><menuitem action=\"open-parent\" /><placeholder name=\"placeholder-"
  "go-history-actions\" /><separator /><menuitem action=\"open-home\" /><m"
  "enuitem action=\"open-desktop\" /><placeholder name=\"placeholder-go-it"
  "ems-actions\" /><menuitem action=\"open-file-system\" /><menuitem actio"
  "n=\"open-templates\" /><separator /><placeholder name=\"placeholder-go-"
  "local-actions\" /><separator /><menuitem action=\"open-network\" /><pla"
  "ceholder name=\"placeholder-go-remote-actions\" /><separator /><menuite"
  "m action=\"open-location\" /></menu><menu action=\"help-menu\"><menuite"
  "m action=\"contents\" /><menuitem action=\"about\" /></menu></menubar><"
  "popup action=\"file-context-menu\"><placeholder name=\"placeholder-laun"
  "cher\" /><separator /><menu action=\"sendto-menu\"><placeholder name=\""
  "placeholder-sendto-sidepane\" /><placeholder name=\"placeholder-sendto-"
  "actions\" /></menu><separator /><placeholder name=\"placeholder-clipboa"
  "rd-actions\" /><separator /><placeholder name=\"placeholder-edit-action"
  "s\" /><separator /><placeholder name=\"placeholder-custom-actions\" /><"
  "separator /><placeholder name=\"placeholder-file-actions\" /></popup><p"
  "opup action=\"tab-context-menu\"><menuitem action=\"new-tab\" /><separa"
  "tor /><menuitem action=\"detach-tab\" /><separator /><menuitem action=\""
  "close-tab\" /></popup><toolbar name=\"location-toolbar\"><placeholder n"
  "ame=\"placeholder-history-actions\" /><toolitem action=\"open-parent\" "
  "/><toolitem action=\"open-home\" /></toolbar></ui>"
};

static const unsigned thunar_window_ui_length = 3244u;

