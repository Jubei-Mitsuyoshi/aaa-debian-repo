/* automatically generated from ./thunar-location-buttons-ui.xml */
#ifdef __SUNPRO_C
#pragma align 4 (thunar_location_buttons_ui)
#endif
#ifdef __GNUC__
static const char thunar_location_buttons_ui[] __attribute__ ((__aligned__ (4))) =
#else
static const char thunar_location_buttons_ui[] =
#endif
{
  "<ui><accelerator action=\"location-buttons-down-folder\" /><popup actio"
  "n=\"location-buttons-context-menu\"><menuitem action=\"location-buttons"
  "-open\" /><menuitem action=\"location-buttons-open-in-new-tab\" /><menu"
  "item action=\"location-buttons-open-in-new-window\" /><separator /><men"
  "uitem action=\"location-buttons-create-folder\" /><menuitem action=\"lo"
  "cation-buttons-empty-trash\" /><separator /><menuitem action=\"location"
  "-buttons-paste-into-folder\" /><separator /><menuitem action=\"location"
  "-buttons-properties\" /></popup></ui>"
};

static const unsigned thunar_location_buttons_ui_length = 516u;

