_arch=(
	i686
	x86_64
	any
)

_tags=(
	core-i686 core-x86_64 core-any
	extra-i686 extra-x86_64 extra-any
	multilib-x86_64
	staging-i686 staging-x86_64 staging-any
	testing-i686 testing-x86_64 testing-any
	multilib-testing-x86_64
	multilib-staging-x86_64
	community-i686 community-x86_64 community-any
	community-staging-i686 community-staging-x86_64 community-staging-any
	community-testing-i686 community-testing-x86_64 community-testing-any
	kde-unstable-i686 kde-unstable-x86_64 kde-unstable-any
	gnome-unstable-i686 gnome-unstable-x86_64 gnome-unstable-any
)
