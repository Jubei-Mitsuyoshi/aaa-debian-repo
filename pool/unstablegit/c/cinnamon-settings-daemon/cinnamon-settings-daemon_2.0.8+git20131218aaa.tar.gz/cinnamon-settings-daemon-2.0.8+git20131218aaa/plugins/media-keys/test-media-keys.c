#define NEW csd_media_keys_manager_new
#define START csd_media_keys_manager_start
#define STOP csd_media_keys_manager_stop
#define MANAGER CsdMediaKeysManager
#include "csd-media-keys-manager.h"

#include "test-plugin.h"
