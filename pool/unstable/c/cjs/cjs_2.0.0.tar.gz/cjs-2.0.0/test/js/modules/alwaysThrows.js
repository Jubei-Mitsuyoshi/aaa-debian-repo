// application/javascript;version=1.8
// line 0
// line 1
// line 2
throw new Error("This is an error that always happens on line 3");
