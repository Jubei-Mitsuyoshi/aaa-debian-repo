#!/usr/bin/python

DEBUG = False

def print_debug (str):
    if DEBUG:
        print str
