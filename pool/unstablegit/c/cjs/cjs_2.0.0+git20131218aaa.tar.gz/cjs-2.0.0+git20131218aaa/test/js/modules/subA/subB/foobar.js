// application/javascript;version=1.8
// simple test module (used by testImporter.js)

var foo = "This is foo";
var bar = "This is bar";
