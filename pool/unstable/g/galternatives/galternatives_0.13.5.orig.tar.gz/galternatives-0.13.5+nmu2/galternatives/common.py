#!/usr/bin/python

PACKAGE='galternatives'
VERSION='0.9'
