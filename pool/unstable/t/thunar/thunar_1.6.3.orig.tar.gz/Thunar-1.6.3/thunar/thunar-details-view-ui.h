/* automatically generated from ./thunar-details-view-ui.xml */
#ifdef __SUNPRO_C
#pragma align 4 (thunar_details_view_ui)
#endif
#ifdef __GNUC__
static const char thunar_details_view_ui[] __attribute__ ((__aligned__ (4))) =
#else
static const char thunar_details_view_ui[] =
#endif
{
  "<ui><menubar name=\"main-menu\"><menu action=\"view-menu\"><placeholder"
  " name=\"placeholder-view-items-actions\"><menuitem action=\"setup-colum"
  "ns\" /></placeholder></menu></menubar></ui>"
};

static const unsigned thunar_details_view_ui_length = 177u;

