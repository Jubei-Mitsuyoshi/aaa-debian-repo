self.description = "Test command line option (--version)"

self.args = "--version"

self.addrule("PACMAN_RETCODE=2")
