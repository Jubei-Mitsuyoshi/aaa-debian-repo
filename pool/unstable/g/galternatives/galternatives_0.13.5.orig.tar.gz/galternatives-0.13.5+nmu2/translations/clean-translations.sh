#!/bin/sh

find . -name \*.mo -exec rm {} \;
