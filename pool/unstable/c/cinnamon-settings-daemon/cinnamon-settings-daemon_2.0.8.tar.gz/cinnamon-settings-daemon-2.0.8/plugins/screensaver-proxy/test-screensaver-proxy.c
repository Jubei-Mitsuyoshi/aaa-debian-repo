#define NEW csd_screensaver_proxy_manager_new
#define START csd_screensaver_proxy_manager_start
#define STOP csd_screensaver_proxy_manager_stop
#define MANAGER CsdScreensaverProxyManager
#include "csd-screensaver-proxy-manager.h"

#include "test-plugin.h"
