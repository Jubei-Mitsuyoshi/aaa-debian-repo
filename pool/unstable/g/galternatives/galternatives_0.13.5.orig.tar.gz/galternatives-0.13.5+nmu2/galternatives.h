/*
 * Arquivo de strings que podem ser traduzidas gerado pelo Glade.
 * Adicione esse arquivo ao POTFILE.in do seu projeto.
 * NÃO compile esse arquivo como parte de sua aplicação.
 */

gchar *s = N_("G Alternatives");
gchar *s = N_("_File");
gchar *s = N_("_Help");
gchar *s = N_("_About");
gchar *s = N_("Status:");
gchar *s = N_("auto");
gchar *s = N_("manual");
gchar *s = N_("<span size=\"xx-large\" weight=\"bold\">Alternative</span>");
gchar *s = N_("No description");
gchar *s = N_("Options");
gchar *s = N_("Details");
gchar *s = N_("Slaves");
gchar *s = N_("About G Alternatives");
gchar *s = N_("<span size=\"xx-large\" weight=\"bold\">G Alternatives</span>");
gchar *s = N_("A tool to help the administrator select which programs provide specific services for the user by default.\n"
              "\n"
              "(C) 2003 Gustavo Noronha Silva");
gchar *s = N_("C_redits");
gchar *s = N_("G Alternatives Credits");
gchar *s = N_("Gustavo Noronha Silva <kov@debian.org>");
gchar *s = N_("Written by");
gchar *s = N_("translator_credits");
gchar *s = N_("Translated by");
gchar *s = N_("Leandro A. F. Pereira <leandro@linuxmag.com.br>");
gchar *s = N_("Thanks to");
gchar *s = N_("Adding option to alternative");
gchar *s = N_("Path:");
gchar *s = N_("*");
gchar *s = N_("_Browse...");
gchar *s = N_("Priority:");
gchar *s = N_("Select File");
