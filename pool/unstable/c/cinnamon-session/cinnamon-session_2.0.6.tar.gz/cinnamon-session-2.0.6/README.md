TODO
____

- Check for regression on power-down sequence (no dialog when laptop power button pressed)


